int searchsign(UTUser *head, char *username)
{
    UTUser *tempSearch = head;
    while (tempSearch != NULL)
    {
        if (!strcmp(tempSearch->username, username)) /* chek kardan user tekrari */
        {
            return 0; /* user tekrari */
        }
        tempSearch = tempSearch->next;
    }
    return 1; /* user tekrari nist */
}