UTUser *signUpFunction(UTUser *head, char *Username, char *Password)
{
    int lenghUsername = 0;
    int lenghPassword = 0;
    UTUser *newUser = (UTUser *)malloc(sizeof(UTUser));
    lenghUsername = strlen(Username);
    lenghPassword = strlen(Password);
    char *newUsername = (char *)malloc(lenghUsername * sizeof(char));
    char *newUserPass = (char *)malloc(lenghPassword * sizeof(char));
    strcpy(newUsername, Username);
    strcpy(newUserPass, Password);
    newUser->username = newUsername;
    newUser->userpass = newUserPass;
    newUser->post=NULL;
    newUser->next = NULL;
    if (head == NULL)
    {
        head = newUser;
        head->next = NULL;
        return head;
    }
    else
    {
        newUser->next = head;
        head = newUser;
    }
    return head;
}