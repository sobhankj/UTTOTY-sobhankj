void search(UTUser *head, char *username)
{
    UTUser *tempSearch = head;
    while (tempSearch != NULL)
    {
        if (!strcmp(tempSearch->username, username)) /* peyda kardan user vared shode */
        {
            searchprint(tempSearch , tempSearch->post);
            return;
        }
        tempSearch = tempSearch->next;
    }
    printf("Username with %s is not found !!!\n", username);
    return;
}