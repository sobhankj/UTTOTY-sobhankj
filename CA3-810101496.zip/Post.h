UTPost *Post(UTPost *headPost, char *post, int *postIdNumber)
{
    int lenghPost = 0;
    UTPost *newPost = (UTPost *)malloc(sizeof(UTPost));
    lenghPost = strlen(post);
    char *newPostC = (char *)malloc(lenghPost * sizeof(char));
    strcpy(newPostC, post);
    newPost->post = newPostC;
    newPost->postNum = *postIdNumber;
    newPost->like = 0;
    newPost->next = NULL;
    if (headPost == NULL)
    {
        headPost = newPost;
        headPost->next = NULL;
        return headPost;
    }
    else
    {
        newPost->next = headPost;
        headPost = newPost;
    }
    return headPost;
}