UTPost *removePost(UTPost *head, int postID)
{
    UTPost *tempsearchpost1 = head;
    UTPost *tempsearchpost2 = head;
    while (tempsearchpost1 != NULL)
    {
        if (tempsearchpost1->postNum == postID) /* peyda kardan id post vared shode */
        {
            if (tempsearchpost1 == tempsearchpost2)
            {
                head = head->next;
                free(tempsearchpost1);
            }
            else
            {
                tempsearchpost2->next = tempsearchpost1->next;
                free(tempsearchpost1);
            }
            return head;
        }
        tempsearchpost2 = tempsearchpost1;
        tempsearchpost1 = tempsearchpost1->next;
    }
    printf("this post not found\n");
    return head;
}