int inputscan(char *inputfirast) /* tabe entekhab commend avalie */
{
    if (!strcmp(inputfirast, "signup"))
    {
        return 1;
    }
    else if (!strcmp(inputfirast, "login"))
    {
        return 2;
    }
    else if (!strcmp(inputfirast, "free"))
    {
        return 0;
    }
    else
    {
        printf("the wrong commend\n");
        return 11;
    }
}