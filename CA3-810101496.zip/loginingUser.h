void loginingUser(UTUser *login, UTUser *head)
{
    int choice = 11;
    int postIdNumber = 1;
    int inputi = 0;
    char *input;
    char *inputfirst;
    inputfirst = (char*)malloc(7*sizeof(char)); /* baraye entekhab commend */
    input = (char *)malloc(100 * sizeof(char)); /* baraye post */
    UTPost *headOfPost = NULL;
    do
    {
        printf("*** login with %s ***\n" , login->username);
        choice = 11;
        fflush(stdin);
        scanf("%s" , inputfirst);
        choice = inputscan2(inputfirst);
        switch (choice)
        {
        case 1: /* post */
            fgets(input, 100, stdin);
            fflush(stdin);
            headOfPost = Post(headOfPost, input, &postIdNumber);
            printf("post saved\n");
            postIdNumber++;
            login->post = headOfPost;
            break;
        case 2: /* search */
            scanf("%s", input);
            fflush(stdin);
            search(head, input);
            break;
        case 3: /* info */
            info(login, login->post);
            choice = 11;
            break;
        case 4: /* like */
            scanf("%s %d", input, &inputi);
            like(head, input, inputi);
            break;
        case 5: /* remove post */
            scanf("%d", &inputi);
            headOfPost = removePost(headOfPost, inputi);
            break;
        case 0: /* logout */
            printf("logout successfully\n");
            break;
        default:
            break;
        }
    } while (choice != 0);
}