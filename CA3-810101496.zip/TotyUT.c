#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define TRUE 1
typedef struct POST UTPost;
struct POST
{
    char *post;
    int postNum;
    int like;
    UTPost *next;
};

typedef struct User UTUser;
struct User
{
    char *username;
    char *userpass;
    UTPost *post;
    UTUser *next;
};
#include "signUpFunction.h" 
#include "searchsign.h" 
#include "endfree.h" 
#include "searchprint.h" 
#include "search.h" 
#include "Post.h" 
#include "info.h" 
#include "login.h" 
#include "like.h" 
#include "removePost.h" 
#include "inputscanlogin.h" 
#include "loginingUser.h" 
#include "inputscan1.h" 
int main(void)
{
    UTUser *head = NULL;
    char *input1, *input2, *inputfirst; 
    input1 = (char *)malloc(100 * sizeof(char)); /* for username */
    input2 = (char *)malloc(100 * sizeof(char)); /* for password */
    inputfirst = (char *)malloc(10 * sizeof(char)); /* this is for commend */
    int choice1, a = 4;
    do
    {
        choice1 = 10;
        fflush(stdin);
        scanf("%s", inputfirst);
        choice1 = inputscan(inputfirst); /* commend dar inja moshakhas mishavad */
        switch (choice1)
        {
        case 1: /* sign up */
            scanf("%s %s", input1, input2);
            fflush(stdin);
            if (searchsign(head, input1)) /* baraye moghavem sazi user tekrari */
            {
                head = signUpFunction(head, input1, input2);
                printf("signup successfully\n");
            }
            else
            {
                printf("This username has already used\n");
            }
            break;
        case 2: /* login */
            scanf("%s %s", input1, input2);
            fflush(stdin);
            login(head, input1, input2);
            break;
        case 0: /* free kardan hame hafeze haie gerefte shode dar akhar barname */
            a = endFree(head);
            printf("%d\n", a);
            break;

        default:
            break;
        }
    } while (choice1 != 0);
}