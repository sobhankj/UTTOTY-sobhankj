int endFree(UTUser *head)
{
    UTUser *tempFree = head;
    UTPost *tempFreePost = head->post;
    while (tempFree != NULL) /* free kardan UTUSER ha */
    {
        free(tempFree);
        tempFree = tempFree->next;
    }
    while (tempFreePost != NULL) /* free karadan UTPOST ha */
    {
        free(tempFreePost);
        tempFreePost = tempFreePost->next;
    }
    return 1;
}