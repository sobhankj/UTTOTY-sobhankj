void info(UTUser *head , UTPost *posthead)
{
    UTUser *tempDisplayinfo = head;
    UTPost *tempDisplayPost = posthead;
    printf("username : %s\n", tempDisplayinfo->username);
    printf("Password : %s\n", tempDisplayinfo->userpass);
    while (tempDisplayPost!=NULL)
    {
        printf("post : %s", tempDisplayPost->post);
        printf("Post ID Number : %d\n", tempDisplayPost->postNum);
        printf("Post like : %d\n", tempDisplayPost->like);
        tempDisplayPost = tempDisplayPost->next;
    }
    return;
}