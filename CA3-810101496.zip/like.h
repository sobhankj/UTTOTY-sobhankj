void like(UTUser *head, char *username, int postID)
{
    UTUser *tempSearch = head;
    while (tempSearch != NULL)
    {
        if (!strcmp(tempSearch->username, username)) /* peyda kardan user entekhab shode */
        {
            UTPost *tempsearchpost = tempSearch->post;
            while (tempsearchpost != NULL)
            {
                if (tempsearchpost->postNum == postID) /* peyda kardan post entekhab shode */
                {
                    tempsearchpost->like += 1;
                    return;
                }
                tempsearchpost = tempsearchpost->next;
            }
            printf("this post is not found\n");
            return;
        }
        tempSearch = tempSearch->next;
    }
    printf("Username with %s is not found !!!\n", username);
    return;
}