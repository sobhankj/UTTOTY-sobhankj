int inputscan2(char *inputfirast) /* tabe entekhab commend */
{
    if (!strcmp(inputfirast, "post"))
    {
        return 1;
    }
    else if (!strcmp(inputfirast, "search"))
    {
        return 2;
    }
    else if (!strcmp(inputfirast, "info"))
    {
        return 3;
    }
    else if (!strcmp(inputfirast, "like"))
    {
        return 4;
    }
    else if (!strcmp(inputfirast, "remove"))
    {
        return 5;
    }
    else if (!strcmp(inputfirast, "logout"))
    {
        return 0;
    }
    else
    {
        printf("the wrong commend\n");
        return 11;
    }
}