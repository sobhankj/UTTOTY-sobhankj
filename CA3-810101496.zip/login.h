void login(UTUser *head, char *username, char *password)
{
    UTUser *templogin = head;
    while (templogin != NULL)
    {
        if (!strcmp(templogin->username, username)) /* peyda kardan user entekhab shode */
        {
            if (!strcmp(templogin->userpass, password)) /* check kardan password vared shode shode */
            {
                loginingUser(templogin , head);
                return;
            }
            else
            {
                printf("Password is not correct\n");
                return;
            }
        }
        templogin = templogin->next;
    }
    printf("Username with %s is not found !!!\n", username);
    return;
}